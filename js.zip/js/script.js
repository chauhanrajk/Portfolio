document.addEventListener("DOMContentLoaded", function() {
    const menuIcon = document.getElementById("menu-icon");
    const navbar = document.querySelector(".navbar");

    menuIcon.addEventListener("click", function() {
        menuIcon.classList.toggle('bx-x'); // Toggle the menu icon class for appearance change
        navbar.classList.toggle('active'); // Toggle the active class to show/hide the navbar
    });

    // Close the navbar when a link inside it is clicked (for smaller screens)
    navbar.querySelectorAll('a').forEach(function(navLink) {
        navLink.addEventListener('click', function() {
            navbar.classList.remove('active'); // Remove active class to close navbar
            menuIcon.classList.remove('bx-x'); // Remove close icon class for appearance
        });
    });
});




// scrool sections active links
let sections = document.querySelectorAll('section');
let navLinks = document.querySelectorAll('header nav a');

window.onscroll = () => {
	sections.forEach(sec => {
		let top = window.scrollY;
		let offset = sec.offsetTop = 150;
		let height = sec.offsetHeight;
		let id = sec.getAttribute('id');

		if(top >= offset && top < offset + height) {
          navLinks.forEach(links => {
          	links.classList.remove('active');
          	document.querySelector('header nav a[href*=' + id + ']').classList.add('active');
          });

		};

	});

	let header = document.querySelector('header');

	header.classList.toggle('sticky',window.scrollY > 100);


};
